package HeliusPackage;

import java.util.Scanner;

public class trueInput {
    private boolean inputChoice;
    private String inputText;
    private int encoderOffsetKey;

    public trueInput(){
        Scanner myObj = new Scanner(System.in);                     // Create a Scanner object
        System.out.println("Enter input text: \t");
        setInputText(myObj.nextLine());
        System.out.println("Decode [true] / Encode [false]: \t");   // Output user input
        setInputChoice(myObj.nextBoolean());
        System.out.println("Input Encoder offset key - or any number if Decoding : \t");
        setEncoderOffsetKey((myObj.nextInt()) % 44);
    }

    public boolean getInputChoice() {
        return inputChoice;
    }
    public void setInputChoice(boolean inputChoice) {
        this.inputChoice = inputChoice;
    }

    public String getInputText() {
        return inputText;
    }
    public void setInputText(String inputText) {
        this.inputText = inputText;
    }

    public int getEncoderOffsetKey() {
        return encoderOffsetKey;
    }
    public void setEncoderOffsetKey(int encoderOffsetKey) {
        this.encoderOffsetKey = encoderOffsetKey;
    }
}