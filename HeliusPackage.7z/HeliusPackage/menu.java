package HeliusPackage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class menu {
    public final ArrayList<Integer> unshiftedCodex = new ArrayList<Integer>(Arrays.asList(65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 40, 41, 42, 43, 44, 45, 46, 47));

    public menu(trueInput userInput){
        if(userInput.getInputChoice()){System.out.println("DECODING....");}
        else{System.out.println("ENCODING....");}
    }

    public String encode (String input, int offsetValue){
        String output = "";                                                 //H e l l o $ _ W o r l d
        input = input.toUpperCase();
        ArrayList<Integer> shiftedCodex = new ArrayList<Integer>();
        shiftedCodex.addAll(unshiftedCodex);
        Collections.rotate(shiftedCodex, offsetValue);

        ArrayList<Integer> charListToCODE = new ArrayList<Integer>();
        ArrayList<Character> inputToCharList = new ArrayList<Character>();

        for (char c : input.toCharArray()) {inputToCharList.add(c);}        //[H,E,L,L,O,$, ,W,O,R,L,D]
        System.out.println(inputToCharList);

        // for length of input STRING as CHAR -> translate char ARRAYLIST to integer ARRAYLIST
        for (Character character : inputToCharList) {                       //H E L L O $ -> 72 69 76 76 79 99
            //H  E  L  L  O  $
            int inputASCIIEquivalent = (int) character;
            if ((inputASCIIEquivalent < 40 || inputASCIIEquivalent > 90) ||
                    (inputASCIIEquivalent >= 58 && inputASCIIEquivalent <= 64) ||
                    (inputASCIIEquivalent == 32)) {                         //if invalid character, replace input index character with spacing
                charListToCODE.add(99);
                }
            else {                                                          //if valid character, convert to ASCII integer
                charListToCODE.add(inputASCIIEquivalent);
                }
        }
        System.out.println(charListToCODE);

        //  for length of integer ARRAYLIST -> translate integer to ASCII value
        for(int b = 0; b < charListToCODE.size(); b++){                     //72 69 76 76 79 99 ->	7 4 11 11 14 99	-> 12 9 16 16 19 99
            if(charListToCODE.get(b) != 99) {							    //if not a spacing value, assigned a CODE equivalent value + offset value (72 -> 12)
                int encodeASCIIEquivalent = (unshiftedCodex.indexOf(charListToCODE.get(b)));
                charListToCODE.set(b, encodeASCIIEquivalent);				//that value replaces the existing value in that position (input[0] = 12)
            }
        }

        output = Character.toString(unshiftedCodex.get(offsetValue));
        System.out.println(charListToCODE);
        System.out.println(output);

        for(int c = 0; c < charListToCODE.size(); c++){
            if(charListToCODE.get(c) != 99){
                //System.out.println(charListToCODE.get(c) + " : " + shiftedCodex.get(charListToCODE.get(c)));
                output = output + Character.toString(shiftedCodex.get(charListToCODE.get(c)));
            }
            else{output = output + (char)32;}
        }

        System.out.println("\nENCODE SUCCESS: " + input + " -> " + output);
        return output;
    }
    public String decode (String input){
        String output = "";                                                 // / I F M M P   X P S M E
        input = input.toUpperCase();
        ArrayList<Integer> shiftedCodex = new ArrayList<Integer>();
        shiftedCodex.addAll(unshiftedCodex);

        char firstChar = input.charAt(0);
        int firstInt = (int)firstChar;
        int offsetValue = unshiftedCodex.indexOf(firstInt);
        Collections.rotate(shiftedCodex, offsetValue);

        ArrayList<Integer> charListToCODE = new ArrayList<Integer>();
        ArrayList<Character> inputToCharList = new ArrayList<Character>();

        for (char c : input.toCharArray()) {inputToCharList.add(c);}        //[/,I,F,M,M,P, ,X,P,S,M,E]
        System.out.println(inputToCharList);

        for(int a = 1; a < inputToCharList.size(); a++){
            if((int)inputToCharList.get(a) != 32) {
                int codeIndex = shiftedCodex.indexOf((int)inputToCharList.get(a));
                int codeEquivalent = unshiftedCodex.get(codeIndex);
                char charEquivalent = (char)codeEquivalent;
                output = output + charEquivalent;
            }
            else {output = output + " ";}
        }
        return output;
    }
}
