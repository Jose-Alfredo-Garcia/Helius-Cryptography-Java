package HeliusPackage;
// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
// TRY PUTTING IT AS A STANDARD OFFSET OF 5
/* the encoder will be approached in two ways
 *
 *	1) The encoding runs on the ASCII table (not the table)
 *		-> SPACE is 32
 *		-> LETTERS are from 65 to 90 (A-Z)
 *		-> NUMBERS are from 48 to 57
 *		-> PUNCTUATIONS are from 40 to 47 [left side parenthesis to forward slash]
 *
 *   2) The encoding runs strictly according to the encoding table
 */

import java.util.*;
public class Main {

    //SHOULD JUST START THINGS, LET THE FUNCTIONS DO THE WORK
    public static void main(String[] args) {
        trueInput userInput = new trueInput();
        menu theMenu = new menu(userInput);
        if(userInput.getInputChoice())
        {System.out.println(theMenu.decode(userInput.getInputText()));}
        else{System.out.println(theMenu.encode(userInput.getInputText(), userInput.getEncoderOffsetKey()));}
    }
}